from django.db import models

class ThreatIntelSource(models.Model):
    SOURCE_TYPES = (
        ('dark_web', 'Dark Web Forum / Marketplace'),
        ('telegram', 'Telegram Channels'),
        ('osint', 'OSINT Feeds'),
        ('hactivist', 'Hacktivist Groups'),
    )
    name = models.CharField(max_length=255)
    source_type = models.CharField(max_length=50, choices=SOURCE_TYPES)
    url = models.CharField(max_length=500, blank=True)
    is_active = models.BooleanField(default=True)
    last_scanned = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} ({self.get_source_type_display()})"


class LiveThreat(models.Model):
    SEVERITY_LEVELS = (
        ('CRITICAL', 'Critical'),
        ('HIGH', 'High'),
        ('MEDIUM', 'Medium'),
        ('LOW', 'Low'),
    )
    title = models.CharField(max_length=300)
    description = models.TextField()
    source = models.ForeignKey(ThreatIntelSource, on_delete=models.CASCADE)
    severity = models.CharField(max_length=20, choices=SEVERITY_LEVELS)
    timestamp = models.DateTimeField(auto_now_add=True)
    target_region = models.CharField(max_length=100, default='Global')
    target_industry = models.CharField(max_length=100, default='Financial')
    actor = models.CharField(max_length=100, blank=True, null=True, help_text="Known threat actor or APT group")
    indicators_of_compromise = models.JSONField(default=list, blank=True, help_text="IPs, Domains, Hashes")
    is_resolved = models.BooleanField(default=False)

    def __str__(self):
        return f"[{self.severity}] {self.title}"


class DarkWebMention(models.Model):
    keyword_matched = models.CharField(max_length=100)
    snippet = models.TextField()
    source = models.ForeignKey(ThreatIntelSource, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    risk_score = models.IntegerField(default=50, help_text="0-100 score formulated by AI Agent")
    ai_analysis = models.TextField(blank=True, help_text="Agentic explanation of the threat context")
    
    def __str__(self):
        return f"Mention: {self.keyword_matched} (Risk {self.risk_score})"
