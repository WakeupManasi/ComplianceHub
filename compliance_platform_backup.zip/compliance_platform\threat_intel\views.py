import json
import random
from datetime import datetime, timedelta
from django.shortcuts import render
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import ThreatIntelSource, LiveThreat, DarkWebMention

@login_required
def threat_dashboard(request):
    # Ensure some dummy sources exist for the hackathon demo
    if not ThreatIntelSource.objects.exists():
        ThreatIntelSource.objects.create(name="XSS Forum", source_type="dark_web", url="onion://xssforum...")
        ThreatIntelSource.objects.create(name="Killnet Official", source_type="telegram", url="t.me/killnet")
        ThreatIntelSource.objects.create(name="AlienVault OTX", source_type="osint")
    
    context = {
        'recent_threats': LiveThreat.objects.order_by('-timestamp')[:5],
        'dark_mentions': DarkWebMention.objects.order_by('-timestamp')[:5]
    }
    return render(request, 'threat_intel/dashboard.html', context)


@login_required
def api_live_threats(request):
    """
    Simulates a live agent feeding JSON threat data to the frontend for visualizations
    Returns data formatted for a real-time JS globe/map and a terminal stream.
    """
    sources = list(ThreatIntelSource.objects.all())
    if not sources:
        return JsonResponse({"threats": []})
        
    # Generate random real-ish looking threats for visual flair
    latitudes = [19.0760, 51.5074, 40.7128, 55.7558, 35.6762, 39.9042, 25.2048, 48.8566]
    longitudes = [72.8777, -0.1278, -74.0060, 37.6173, 139.6503, 116.4074, 55.2708, 2.3522]
    cities = ["Mumbai", "London", "New York", "Moscow", "Tokyo", "Beijing", "Dubai", "Paris"]
    
    threat_types = ["Ransomware Deployment", "Data Exfiltration", "DDoS TCP Flood", "Zero-day Exploit", "Credential Stuffing"]
    severities = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
    
    threats_data = []
    for _ in range(random.randint(2, 5)):
        idx = random.randint(0, len(latitudes) - 1)
        sev = random.choices(severities, weights=[10, 30, 40, 20])[0]
        
        threats_data.append({
            "id": random.randint(1000, 9999),
            "type": random.choice(threat_types),
            "location": cities[idx],
            "lat": latitudes[idx] + random.uniform(-2, 2),
            "lng": longitudes[idx] + random.uniform(-2, 2),
            "severity": sev,
            "ip": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
    return JsonResponse({"threats": threats_data})

@login_required
def api_trigger_agent_scan(request):
    """
    A view to trigger the AI agent scanning with target parameters
    """
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            target_user = data.get("user_email", "unknown_user@domain.com")
            target_org = data.get("organizer_email", "admin@domain.com")
        except:
            target_user = "unknown_user@domain.com"
            target_org = "admin@domain.com"
            
        source = ThreatIntelSource.objects.filter(source_type="dark_web").first()
        if source:
            DarkWebMention.objects.create(
                keyword_matched=f"{target_user}, {target_org}",
                snippet=f"Found a database dump mentioning [{target_org}]. Looks like user data containing credentials for {target_user}...",
                source=source,
                risk_score=random.randint(70, 99),
                ai_analysis=f"Agent verified hash samples against our internal schema matching {target_user}. 85% probability of a real leak. Recommended action: Force password reset."
            )
            LiveThreat.objects.create(
                title=f"Targeted Leak: {target_org}",
                description=f"Our Dark Web Agent detected discussion of a database dump associated with target emails.",
                source=source,
                severity="CRITICAL",
                target_region="Global",
                target_industry="Internal",
                actor="Unknown",
                indicators_of_compromise={"domain_mentions": [target_org]}
            )
    
    return JsonResponse({"status": "Agent scan complete", "new_findings": 2})
