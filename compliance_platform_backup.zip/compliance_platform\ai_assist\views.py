import json
import requests

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST


OLLAMA_URL = 'http://172.236.213.60:11434/api/generate'

PROMPT_TEMPLATES = {
    'cve': 'Explain this CVE in simple terms and its potential impact: {text}',
    'control': 'Explain this compliance control and why it matters: {text}',
    'mitigation': 'Suggest a mitigation strategy for: {text}',
}


@login_required
@require_POST
def ai_explain(request):
    """
    Accept a query and context_type, send to Ollama LLM, return explanation.
    Falls back gracefully if Ollama is unavailable.
    """
    try:
        body = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON body.'}, status=400)

    query = body.get('query', '').strip()
    context_type = body.get('context_type', '').strip()

    if not query:
        return JsonResponse({'error': 'A query is required.'}, status=400)

    template = PROMPT_TEMPLATES.get(context_type)
    if not template:
        return JsonResponse(
            {'error': f'Invalid context_type. Choose from: {", ".join(PROMPT_TEMPLATES.keys())}'},
            status=400,
        )

    prompt = template.format(text=query)

    # Try llama3.2 first, then mistral as fallback
    for model in ('llama3.2', 'mistral'):
        try:
            response = requests.post(
                OLLAMA_URL,
                json={
                    'model': model,
                    'prompt': prompt,
                    'stream': False,
                },
                timeout=10,
            )
            if response.status_code == 200:
                data = response.json()
                return JsonResponse({
                    'response': data.get('response', ''),
                    'model': model,
                    'context_type': context_type,
                })
        except (requests.ConnectionError, requests.Timeout):
            continue
        except requests.RequestException:
            continue

    # Fallback when Ollama is unavailable
    fallback_messages = {
        'cve': (
            'AI analysis is currently unavailable. For CVE information, '
            'please consult the NVD database at https://nvd.nist.gov/ '
            'or review the CVE details in the system.'
        ),
        'control': (
            'AI analysis is currently unavailable. Please review the '
            'control documentation and associated framework guidance '
            'for detailed information.'
        ),
        'mitigation': (
            'AI analysis is currently unavailable. Consider reviewing '
            'industry best practices and your organization\'s risk '
            'management playbook for mitigation strategies.'
        ),
    }

    return JsonResponse({
        'response': fallback_messages.get(context_type, 'AI analysis is currently unavailable. Please try again later.'),
        'model': 'fallback',
        'context_type': context_type,
    })


@login_required
def ai_chat(request):
    """Render the AI chat interface template."""
    return render(request, 'ai_assist/chat.html')
