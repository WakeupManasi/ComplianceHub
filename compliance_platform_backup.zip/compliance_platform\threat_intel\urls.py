from django.urls import path
from . import views

app_name = 'threat_intel'

urlpatterns = [
    path('', views.threat_dashboard, name='dashboard'),
    path('api/live/', views.api_live_threats, name='api_live_threats'),
    path('api/scan/', views.api_trigger_agent_scan, name='api_trigger_scan'),
]
